StartupEvents.registry("item", (event) => {
  event.create("greg_icon");
});

Platform.mods.kubejs.name = "GregTech Community Pack";
