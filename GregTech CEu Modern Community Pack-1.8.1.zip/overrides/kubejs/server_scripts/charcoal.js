ServerEvents.recipes((event) => {
  event.remove({id: "minecraft:charcoal"})
});
