ServerEvents.tags("item", (event) => {
  event.add("forge:meat", "minecraft:chicken");
  event.add("forge:meat", "minecraft:cooked_chicken");
  event.add("forge:meat", "minecraft:beef");
  event.add("forge:meat", "minecraft:cooked_beef");
  event.add("forge:meat", "minecraft:porkchop");
  event.add("forge:meat", "minecraft:cooked_porkchop");
  event.add("forge:meat", "minecraft:mutton");
  event.add("forge:meat", "minecraft:cooked_mutton");
  event.add("forge:meat", "minecraft:rabbit");
  event.add("forge:meat", "minecraft:cooked_rabbit");
});
