ServerEvents.tags("item", (event) => {
  event.add("forge:rods/long/hsla", "kubejs:hsla_steel_long_rod");
  event.add("forge:springs/hsla", "kubejs:hsla_steel_spring");
});
