ServerEvents.tags("block", (event) => {
  event.add("forge:mineable/wrench", "travelanchors:travel_anchor");
});
